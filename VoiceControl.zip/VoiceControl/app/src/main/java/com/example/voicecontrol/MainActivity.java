package com.example.voicecontrol;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;

import android.os.Bundle;

import com.example.voicecontrol.databinding.ActivityMainBinding;

public class MainActivity extends AppCompatActivity {
    ActivityMainBinding vincular;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        vincular =  ActivityMainBinding.inflate(getLayoutInflater());
        setContentView(vincular.getRoot());
        replaceFragment(new CasaFragment());
        vincular.btnNavView.setOnItemSelectedListener(item -> {

            if (item.getItemId()==R.id.casa) {
                replaceFragment(new CasaFragment());
            }else if (item.getItemId()==R.id.voz){
                replaceFragment(new FalarFragment());
            }else if (item.getItemId()==R.id.configurar){
                replaceFragment(new ConfigFragment());
            }

           return true;
        });

    }
        private void replaceFragment(Fragment fragment){
            FragmentManager fragmentManager = getSupportFragmentManager();
            FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
            fragmentTransaction.replace(R.id.frame_layout,fragment);

        }
}